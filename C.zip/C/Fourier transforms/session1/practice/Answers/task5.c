#include <stdio.h>
void main()
{
 double x;
 x=3.; //3. is same as 3.0
 if (x > 5)
 {
  printf("x = %f > 5.\n", x);
 }
}

