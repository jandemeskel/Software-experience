#include <stdio.h>

void main()
{
	float x, y, result;
	x = 5.0;
	y = 7.0;
	result = x + y;
	{
		printf("x + y = %.2f\n", result);
	}
}