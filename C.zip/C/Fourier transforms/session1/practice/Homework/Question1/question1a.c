#include <stdio.h>

void main()
{
	int x, y, result;
	x = 5;
	y = 7;
	result = x + y;
	{
		printf("x + y = %d\n", result);
	}
}