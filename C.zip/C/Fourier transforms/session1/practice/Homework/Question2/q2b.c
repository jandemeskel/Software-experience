#include <stdio.h> 

void main()
{
  int i;
  for (i = 1; i < 13; i++)
  {
    printf("%2d x 7 = %2d\n", i, i * 7);
  }
}