#include <stdio.h>

 void main() {
  int x = 10;
   while(--x) 
   if (x = 0) {
   printf("x is zero");
 }
  else{
   printf("%f\n",(float)5/x); }
 }


