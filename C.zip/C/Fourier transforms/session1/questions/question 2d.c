int x = 10;
while(--x) { printf("%f\n",(float)5/x); }

