#include <stdio.h>

 void main() {
 float x, y, z;

 printf("value of variable x: ");
 scanf("%f", &x);

 printf("value of variable y: ");
 scanf("%f",&y);

 z = x/y;
 printf("x/y is %.3f\n",z);
}
