#include <stdio.h>

 void main() {
 char x;

  printf("choose a variable name is: ");
  scanf("%c", &x);
  
  printf("choosen variable name is %c\n",x);
}
