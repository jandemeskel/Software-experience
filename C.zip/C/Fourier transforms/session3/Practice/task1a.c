#include <stdio.h>

int main()
{
 int t1[100];
 int result = t1[];
 printf("first array value is %d\n", result);
}
