#include <stdio.h>

int main()
 {
int n;
  printf("give array size");
  scanf("%d", &n);
int t2[n];
int i;

for (i=0;i<n;i++){
int result = t2[i];
printf("first n array elements are %d\n", result);
 }
}
