#include <stdio.h>

int main(){
char s[10];
 printf("what is your name");
 scanf("%s",s);

char result = s[2];
printf("%c\n", result);
}
 
