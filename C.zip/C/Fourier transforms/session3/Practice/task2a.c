#include <stdio.h>

int main()
 {
int t2[] = {0,1,2,3,4,5};
int i;
for (i=0;i<7;i++){
int result = t2[i];
printf("first n array elements are %d\n", result);
 }
}
