#include <stdio.h>

int main()
{
 printf("size of interger is %zu\n", sizeof(int));
 printf("size of character is %zu\n", sizeof(char));
 printf("size of float is %zu\n", sizeof(float));
 printf("size of double is %zu\n", sizeof(double));
 printf("size of long is %zu\n", sizeof(long));
 
 return 0;
}


