

------------------------- Exercise 1

square :: Int -> Int
square x = undefined

pythagoras a b c = undefined


------------------------- Exercise 2

factorial :: Int -> Int
factorial x
    | x <= 1    = undefined
    | otherwise = undefined

euclid :: Int -> Int -> Int
euclid x y
    | x == y = undefined
    | x <  y = undefined
    | x >  y = undefined

power :: Int -> Int -> Int
power x y = undefined
--note: you will need to create your own cases,
--      replacing the equals (=) sign with guards


------------------------- Exercise 3

range :: Int -> Int -> [Int]
range = undefined
--note: you will need to create your own guards
--      and add your own parameters

times :: [Int] -> Int
times = undefined
--note: you will need to create your own pattern-matching

fact :: Int -> Int
fact = undefined