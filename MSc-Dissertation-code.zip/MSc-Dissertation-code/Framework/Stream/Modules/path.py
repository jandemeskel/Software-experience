
class test():
    def __init__(self):
        print("\n")
        print('test module accessed')
        print('correctly installed!')
        print("\n")
    
        return None