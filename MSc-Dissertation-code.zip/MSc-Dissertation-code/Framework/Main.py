import Stream.Modules.Muller_input as input
import Stream.Modules.NGA_conversion as convertNGA


Example_Input = input.NMA().construct_FD()
Example_NGA = convertNGA.NGA().construct_NGAs()



def comp(NGA):

    complement = []

    # manipulate NGA array to perform the complement algorithm

    return complement


NGA_complement = comp(Example_NGA)

